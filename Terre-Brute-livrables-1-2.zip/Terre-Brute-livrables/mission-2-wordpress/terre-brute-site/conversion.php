<?php
if(!defined('ABSPATH'))exit;
function tbs_quick_gift_form($product_id,$label='Offrir cette formule'){
 $p=wc_get_product($product_id);if(!$p||!$p->is_purchasable()||!$p->is_in_stock())return '<p>Cette formule n’est pas disponible actuellement.</p>';
 $id='tbs-quantity-'.$product_id;ob_start();echo '<form class="tbs-quick-buy" method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-quick-buy data-offer="cadeau"><input type="hidden" name="action" value="tbs_buy_now"><input type="hidden" name="kind" value="gift"><input type="hidden" name="product_id" value="'.esc_attr($product_id).'">';wp_nonce_field('tbs_buy_now','tbs_buy_nonce');echo '<label for="'.esc_attr($id).'">Nombre de personnes</label><input id="'.esc_attr($id).'" type="number" name="quantity" min="1" max="8" value="1" required inputmode="numeric"><button type="submit" class="button">'.esc_html($label).' →</button><p class="tbs-quick-note">Paiement à l’étape suivante / Carte valable un an.</p></form>';return ob_get_clean();
}
function tbs_quick_booking_form($atelier){
 if(function_exists('wc_print_notices'))wc_print_notices();
 $slots=tbs_booking_options($atelier);$id='tbs-quick-slot-'.$atelier;if(!$slots){echo '<p>Aucune date disponible actuellement. <a href="'.esc_url(tbs_url('contact')).'">Contactez l’atelier</a> pour le prochain rendez-vous.</p>';return;}
 echo '<form class="tbs-quick-buy tbs-quick-booking" method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-quick-buy data-offer="atelier"><input type="hidden" name="action" value="tbs_buy_now"><input type="hidden" name="kind" value="booking"><input type="hidden" name="atelier_id" value="'.esc_attr($atelier).'">';wp_nonce_field('tbs_buy_now','tbs_buy_nonce');echo '<label for="'.esc_attr($id).'">Date et horaire *</label><select id="'.esc_attr($id).'" name="product_id" required><option value="">Choisir une date disponible</option>';foreach($slots as $pid=>$p){$date=get_post_meta($pid,'_tbs_booking_date',true);echo '<option value="'.esc_attr($pid).'">'.esc_html(wp_date('d/m/Y',strtotime($date)).' / '.get_post_meta($pid,'_tbs_booking_label',true).' / '.$p->get_stock_quantity().' places').'</option>';}
 echo '</select><label for="tbs-quick-qty-'.esc_attr($atelier).'">Nombre de personnes</label><input id="tbs-quick-qty-'.esc_attr($atelier).'" type="number" name="quantity" min="1" max="8" value="1" required inputmode="numeric"><button type="submit" class="button">Réserver et passer au paiement →</button><p class="tbs-quick-note">Atelier ouvert du mardi au samedi, de 10 h à 19 h. Les places sont vérifiées avant l’ajout au panier.</p></form>';
}
function tbs_handle_buy_now(){
 if(!function_exists('WC'))wp_die('La réservation est indisponible.');if(!WC()->cart)wc_load_cart();
 $pid=absint($_POST['product_id']??0);$qty=absint($_POST['quantity']??0);$kind=sanitize_key($_POST['kind']??'');$parent=absint($_POST['atelier_id']??0);$back=$kind==='booking'&&get_post_type($parent)==='tb_atelier'?get_permalink($parent):tbs_url('cartes-cadeaux');
 $fail=function($text)use($back){wc_add_notice($text,'error');wp_safe_redirect($back);exit;};
 if(!isset($_POST['tbs_buy_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tbs_buy_nonce'])),'tbs_buy_now'))$fail('Votre page a expiré. Rechargez-la puis réessayez.');
 if(!is_scalar($_POST['quantity']??null)||!preg_match('/^[1-8]$/',(string)$_POST['quantity'])||$qty<1||$qty>8)$fail('Choisissez entre 1 et 8 personnes.');
 if($kind==='gift'){if(!in_array($pid,array_map('absint',(array)get_option('tbs_gift_ids',array())),true))$fail('Choisissez une formule disponible.');}
 elseif($kind==='booking'){if(!$parent||!array_key_exists($pid,tbs_booking_options($parent)))$fail('Choisissez une date disponible pour cet atelier.');}
 else $fail('Cette sélection n’est pas reconnue.');
 $p=wc_get_product($pid);if(!$p||!$p->is_purchasable()||!$p->is_in_stock()||!$p->has_enough_stock($qty))$fail('Il ne reste pas assez de places pour cette sélection.');
 if(!apply_filters('woocommerce_add_to_cart_validation',true,$pid,$qty))$fail('Ce créneau ne peut plus être réservé. Choisissez une autre date.');
 $added=WC()->cart->add_to_cart($pid,$qty);if(!$added)$fail('La sélection n’a pas pu être ajoutée. Vérifiez les quantités de votre panier.');
 wp_safe_redirect(wc_get_checkout_url());exit;
}
add_action('admin_post_tbs_buy_now','tbs_handle_buy_now');add_action('admin_post_nopriv_tbs_buy_now','tbs_handle_buy_now');
// La fiche détaillée reste disponible, avec un accès direct au paiement si on la consulte.
add_filter('woocommerce_product_single_add_to_cart_text',function($label){return 'Choisir et passer au paiement';});
add_filter('woocommerce_add_to_cart_redirect',function($url){if(is_admin())return $url;$pid=absint($_REQUEST['add-to-cart']??0);if($pid&&(get_post_meta($pid,'_tbs_booking_parent',true)||in_array($pid,array_map('absint',(array)get_option('tbs_gift_ids',array())),true)))return wc_get_checkout_url();return $url;},30);
add_action('wp_enqueue_scripts',function(){wp_enqueue_style('tbs-conversion',plugins_url('conversion.css',__FILE__),array(),'1.0.34');},120);

// Conserver un seul simulateur natif si une ancienne migration l’a ajouté deux fois.
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||get_option('tbs_conversion_cleanup')==='2')return;
 $page=get_page_by_path('cartes-cadeaux');if(!$page)return;
 $seen=false;$changed=false;
 $clean=function($blocks)use(&$clean,&$seen,&$changed){$out=array();foreach($blocks as $block){
  if(($block['attrs']['anchor']??'')==='simulateur-cadeau'){if($seen){$changed=true;continue;}$seen=true;}
  if(!empty($block['innerBlocks'])){$children=array();$content=array();$index=0;foreach($block['innerContent'] as $part){if($part!==null){$content[]=$part;continue;}$child=$clean(array($block['innerBlocks'][$index++]));if($child){$children[]=$child[0];$content[]=null;}}$block['innerBlocks']=$children;$block['innerContent']=$content;}
  $out[]=$block;}return $out;};
 $blocks=$clean(parse_blocks($page->post_content));
 if($changed){update_option('tbs_conversion_gift_backup',$page->post_content,false);$result=wp_update_post(wp_slash(array('ID'=>$page->ID,'post_content'=>serialize_blocks($blocks))),true);if(is_wp_error($result))return;wp_cache_flush();}
 update_option('tbs_conversion_cleanup','2');
});
