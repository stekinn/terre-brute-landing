/* Une seule destination Google : GA4 via le conteneur GTM, après accord. */
(() => {
 'use strict';
 const cfg=window.tbsMeasureConfig||{}, key='tbs_analytics_consent_v1';
 let enabled=false,loaded=false,queue=[],banner,debug;
 const safePath=location.origin+location.pathname;
 const read=(store,k)=>{try{return store.getItem(k)}catch{return null}};
 const write=(store,k,v)=>{try{store.setItem(k,v)}catch{}};
 const clear=(store,k)=>{try{store.removeItem(k)}catch{}};
 function log(event){if(debug){const row=document.createElement('pre');row.textContent=JSON.stringify(event,null,2);debug.append(row);}}
 function push(event){
  const payload={...event,test_mode:!!cfg.testMode};
  if(cfg.debug)payload.debug_mode=true;
  if(payload.event==='purchase'){
   const id=payload.ecommerce?.transaction_id;if(!id)return;
   const sent='tbs_purchase_sent_'+cfg.ga4Id+'_'+id;if(read(localStorage,sent))return;
   write(localStorage,sent,'1');
  }
  window.dataLayer=window.dataLayer||[];
  if(payload.ecommerce)window.dataLayer.push({ecommerce:null});
  window.dataLayer.push(payload);log(payload);
 }
 function emit(event){
  // Aucun contact, message, adresse, clé de commande ou champ libre n’est collecté.
  if(enabled)push(event);else if(queue.length<60)queue.push(event);
 }
 function consent(value){
  write(localStorage,key,JSON.stringify({value,at:Date.now()}));
  document.documentElement.dataset.tbsAnalyticsConsent=value;
  if(banner)banner.hidden=true;
  if(value!=='granted'){
   enabled=false;queue=[];window['ga-disable-'+cfg.ga4Id]=true;
   // Révoquer les cookies de mesure existants sur les domaines courants du site.
   document.cookie.split(';').forEach(v=>{const name=v.split('=')[0].trim();if(/^_ga(?:_|$)|^_gid$|^_gat/.test(name)){const domains=[location.hostname,'.'+location.hostname];domains.forEach(domain=>{document.cookie=name+'=; Max-Age=0; path=/; domain='+domain+'; SameSite=Lax';});document.cookie=name+'=; Max-Age=0; path=/; SameSite=Lax';}});
   if(loaded)location.reload();return;
  }
  enabled=true;window['ga-disable-'+cfg.ga4Id]=false;
  if(!loaded){
   loaded=true;window.dataLayer=window.dataLayer||[];
   // Valeurs d’initialisation disponibles avant les balises GTM.
   window.dataLayer.push({tbs_page_location:safePath,tbs_page_referrer:document.referrer?new URL(document.referrer).origin+new URL(document.referrer).pathname:'',tbs_analytics_consent:'granted'});
   window.dataLayer.push({'gtm.start':Date.now(),event:'gtm.js'});
   const script=document.createElement('script');script.async=true;script.src='https://www.googletagmanager.com/gtm.js?id='+encodeURIComponent(cfg.gtmId);document.head.append(script);
   push({event:'page_view',page_location:safePath,page_title:document.title});
  }
  const pending=queue;queue=[];pending.forEach(push);
 }
 function init(){
  banner=document.querySelector('[data-tbs-consent]');
  if(cfg.debug){debug=document.createElement('details');debug.className='tbs-measure-debug';debug.open=true;const title=document.createElement('summary');title.textContent='Diagnostic de mesure / événements autorisés';debug.append(title);document.body.append(debug);}
  (cfg.events||[]).forEach(emit);
  const saved=read(localStorage,key);let choice;
  try{const s=JSON.parse(saved);if(s&&Date.now()-s.at<180*86400000)choice=s.value;}catch{}
  if(choice==='granted')consent('granted');else if(choice!=='denied'&&banner)banner.hidden=false;
  document.querySelectorAll('[data-tbs-consent-choice]').forEach(b=>b.addEventListener('click',()=>consent(b.dataset.tbsConsentChoice)));
  document.querySelector('[data-tbs-consent-settings]')?.addEventListener('click',()=>{banner.hidden=false;banner.querySelector('button')?.focus();});
  document.addEventListener('click',e=>{
   const a=e.target.closest('a,button');if(!a)return;
   const label=a.textContent.replace(/\s+/g,' ').trim();
   if(/^Offrir un atelier$/.test(label)){
    const position=a.closest('header')?'header':a.closest('footer')?'footer':a.closest('main')?'hero':'autre';
    emit({event:'cta_click',cta_name:'offrir_un_atelier',cta_location:position});
   }
  },true);
  document.querySelectorAll('form[data-quick-buy]').forEach(f=>f.addEventListener('submit',()=>{
   if(!f.checkValidity())return;
   emit({event:'cta_click',cta_name:'choisir_paiement',cta_location:f.dataset.offer==='atelier'?'fiche_atelier':'offres_cadeaux'});
   const b=f.querySelector('button[type=submit]');if(b){b.disabled=true;b.textContent='Préparation…';}
  }));
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
