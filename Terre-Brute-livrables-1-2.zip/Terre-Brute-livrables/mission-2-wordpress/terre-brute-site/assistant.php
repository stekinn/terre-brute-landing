<?php
/** Assistant public ElevenLabs : aucune clé privée dans le navigateur. */
if (!defined('ABSPATH')) exit;
function tbs_terra_agent_id(){return get_option('tbs_terra_agent_id','agent_7801m63ezfz6fh7rt2sz12gncp4e');}
add_action('admin_init',function(){
 register_setting('tbs_terra','tbs_terra_agent_id',array('type'=>'string','sanitize_callback'=>function($value){$value=sanitize_text_field($value);return preg_match('/^agent_[a-zA-Z0-9]+$/',$value)?$value:'';}));
 if(!current_user_can('manage_options')||get_option('tbs_terra_privacy_version'))return;
 $page=get_page_by_path('confidentialite');
 if($page&&strpos($page->post_content,'ElevenLabs')===false){
  $extra='<!-- wp:heading --><h2 class="wp-block-heading">Assistant virtuel Terra</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Terra répond en texte ou à la voix grâce au service ElevenLabs. Lorsque vous démarrez une conversation, vos messages et, si vous activez le microphone, votre voix sont transmis à ce service pour produire une réponse. Les échanges peuvent être conservés dans le journal de conversations du compte de l’atelier selon sa configuration. N’y communiquez pas de coordonnées bancaires, de mot de passe ou de données sensibles.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Vous pouvez utiliser les pages du site et le formulaire Contact sans ouvrir Terra. L’assistant donne des informations et ne confirme aucune réservation. Pour toute demande concernant vos échanges, contactez l’équipe via la page Contact. En savoir plus : <a href="https://elevenlabs.io/privacy-policy" target="_blank" rel="noopener">politique de confidentialité ElevenLabs</a>.</p><!-- /wp:paragraph -->';
  $result=wp_update_post(array('ID'=>$page->ID,'post_content'=>$page->post_content.$extra),true);
  if(!is_wp_error($result))update_option('tbs_terra_privacy_version','1');
 }elseif($page){update_option('tbs_terra_privacy_version','1');}
});
add_action('admin_menu',function(){add_options_page('Assistant Terra','Assistant Terra','manage_options','terre-brute-assistant','tbs_terra_settings_page');});
function tbs_terra_settings_page(){
 if(!current_user_can('manage_options'))return;
 echo '<div class="wrap"><h1>Assistant Terra</h1><p>La voix, les réponses et les couleurs se modifient dans le tableau de bord ElevenLabs. Cet écran gère l’identifiant public utilisé sur le site. Ne collez jamais de clé API.</p><form action="options.php" method="post">';
 settings_fields('tbs_terra');
 echo '<p><label for="tbs-terra-id">Identifiant public de l’agent</label><br><input class="regular-text" id="tbs-terra-id" name="tbs_terra_agent_id" value="'.esc_attr(tbs_terra_agent_id()).'"></p><p>Vider ce champ désactive le widget. Le widget n’est pas chargé sur la page de paiement.</p>';
 submit_button('Enregistrer');echo '</form></div>';
}
function tbs_terra_enabled(){return !is_admin()&&tbs_terra_agent_id()&&!(function_exists('is_checkout')&&is_checkout());}
add_action('wp_enqueue_scripts',function(){
 if(!tbs_terra_enabled())return;
 wp_enqueue_style('tbs-terra-launcher',plugins_url('assistant.css',__FILE__),array(),'1.0.37');
 wp_enqueue_script('tbs-terra-loader',plugins_url('assistant-loader.js',__FILE__),array(),'1.0.37',true);
},110);
add_action('wp_footer',function(){
 if(!tbs_terra_enabled())return;
 echo '<div class="tbs-terra-launcher" data-terra-launcher data-agent="'.esc_attr(tbs_terra_agent_id()).'"><button type="button" aria-label="Ouvrir Terra, assistant texte et voix"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M20 11.5a8 8 0 0 1-8 8H5l-3 2v-10a9 9 0 0 1 18 0Z"/><path d="M7 10h10M7 14h7"/></svg><span>Une question ?<br>Terra vous guide.</span></button><span class="tbs-terra-status" role="status" aria-live="polite"></span></div>';
},40);
