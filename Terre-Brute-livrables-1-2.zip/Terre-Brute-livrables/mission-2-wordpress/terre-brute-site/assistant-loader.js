/* Terra affiche directement ses choix texte et voix ; aucun microphone ne démarre automatiquement. */
document.addEventListener('DOMContentLoaded',()=>{
 const launcher=document.querySelector('[data-terra-launcher]');if(!launcher)return;
 const button=launcher.querySelector('button'),status=launcher.querySelector('[role="status"]');
 let loading=false;
 const openTerra=async()=>{
  if(loading)return;launcher.hidden=true;loading=true;button.disabled=true;status.textContent='Chargement de Terra…';
  try{
   if(!customElements.get('elevenlabs-convai')){
    await new Promise((resolve,reject)=>{
     const script=document.createElement('script');let timer=setTimeout(()=>{script.remove();reject(new Error('Délai dépassé'));},15000);
     script.src='https://unpkg.com/@elevenlabs/convai-widget-embed';script.async=true;
     script.onload=()=>{clearTimeout(timer);resolve();};script.onerror=()=>{clearTimeout(timer);script.remove();reject(new Error('Chargement impossible'));};document.head.append(script);
    });
    await Promise.race([customElements.whenDefined('elevenlabs-convai'),new Promise((_,reject)=>setTimeout(()=>reject(new Error('Widget indisponible')),15000))]);
   }
   const widget=document.createElement('elevenlabs-convai');widget.setAttribute('agent-id',launcher.dataset.agent);widget.setAttribute('override-language','fr');widget.setAttribute('variant','expanded');widget.setAttribute('avatar-orb-color-1','#A0472A');widget.setAttribute('avatar-orb-color-2','#EDE6DC');
   document.body.append(widget);launcher.hidden=true;status.textContent='';
  }catch(error){launcher.hidden=false;status.textContent='Terra ne se charge pas. Réessayez ou utilisez la page Contact.';button.disabled=false;loading=false;}
 };
 button.addEventListener('click',openTerra);
 openTerra();
});
