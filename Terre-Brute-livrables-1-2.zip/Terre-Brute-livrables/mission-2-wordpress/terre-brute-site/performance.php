<?php
/** Optimisations de rendu, sans modifier les blocs enregistrés ni les originaux. */
if (!defined('ABSPATH')) exit;
function tbs_perf_image_family($src){
 $path=(string)wp_parse_url($src,PHP_URL_PATH);
 foreach(array('pexels-eyupbeyhan-16428207'=>'initiation','pexels-raymond-petrik-1448389535-37984758'=>'stage','hands-doing-pottery-close-up'=>'cycle','terre-brute-instagram'=>'instagram') as $needle=>$family){if(strpos($path,$needle)!==false)return $family;}
 return '';
}
function tbs_perf_html($html){
 if(is_admin()||is_feed()||!class_exists('WP_HTML_Tag_Processor')||!is_string($html)||strpos($html,'<img')===false)return $html;
 $wide=strpos($html,'tb-native-community')!==false;
 $tags=new WP_HTML_Tag_Processor($html);
 while($tags->next_tag('IMG')){
  $family=tbs_perf_image_family((string)$tags->get_attribute('src'));if(!$family)continue;
  $url=plugins_url('assets/performance/'.$family.'-',__FILE__);$set=array();
  foreach(array(480,768,1200,1600) as $width)$set[]=$url.$width.'.webp '.$width.'w';
  $class=(string)$tags->get_attribute('class');
  $large=$wide||$family==='instagram'||strpos($class,'tbs-cover')!==false||strpos($class,'tbs-product-image')!==false;
  $sizes=$large?'(max-width: 767px) 100vw, (max-width: 1200px) 90vw, 1200px':(is_front_page()?'(max-width: 767px) 88vw, (max-width: 1100px) 30vw, 380px':'(max-width: 767px) 100vw, (max-width: 1200px) 50vw, 600px');
  $tags->set_attribute('src',$url.'768.webp');$tags->set_attribute('srcset',implode(', ',$set));$tags->set_attribute('sizes',$sizes);
  $tags->set_attribute('width','1600');$tags->set_attribute('height',$family==='instagram'?'533':'2400');$tags->set_attribute('decoding','async');
  if(is_front_page()){$tags->set_attribute('loading','lazy');$tags->remove_attribute('fetchpriority');}
 }
 return $tags->get_updated_html();
}
add_filter('render_block',function($html,$block){return in_array($block['blockName']??'',array('core/image','core/html','core/freeform'),true)?tbs_perf_html($html):$html;},100,2);
add_filter('the_content','tbs_perf_html',100);
add_filter('post_thumbnail_html','tbs_perf_html',100);
add_filter('style_loader_src',function($src,$handle){return in_array($handle,array('tb-landing','tb-base'),true)?plugins_url('assets/landing-fast.css',__FILE__).'?ver=1.0.31':$src;},100,2);
add_action('wp_head',function(){
 if(is_admin())return;
 foreach(array('fraunces-latin.woff2','inter-latin.woff2') as $font)echo '<link rel="preload" href="'.esc_url(plugins_url('assets/fonts/'.$font,__FILE__)).'" as="font" type="font/woff2" crossorigin>';
},1);
add_action('wp_enqueue_scripts',function(){
 if(!is_front_page()){
  wp_register_style('tbs-performance',false,array(),'1.0.31');wp_enqueue_style('tbs-performance');
  wp_add_inline_style('tbs-performance','.tbs-site .tb-texture{background-image:url("'.esc_url(plugins_url('assets/performance/texture-1920.webp',__FILE__)).'")}');
  return;
 }
 // L’accueil n’a pas de formulaire WooCommerce : conserver les scripts du panier,
 // mais supprimer ses feuilles de catalogue et les allers-retours CSS locaux.
 foreach(array('woocommerce-layout','woocommerce-smallscreen','woocommerce-general','woocommerce-blocktheme','wc-blocks-style') as $handle)wp_dequeue_style($handle);
 foreach(array('tb-landing','tb-base','tbs-home','tbs-commerce','tbs-newsletter','tbs-terra-launcher') as $handle)wp_dequeue_style($handle);
 $base=plugins_url('assets/',__FILE__);$css=file_get_contents(__DIR__.'/assets/landing-fast.css');
 $css=str_replace(array('url("fonts/','url("performance/'),array('url("'.$base.'fonts/','url("'.$base.'performance/'),$css);
 foreach(array('home.css','commerce.css','newsletter.css','assistant.css') as $file)$css.="\n".file_get_contents(__DIR__.'/'.$file);
 wp_register_style('tbs-performance',false,array(),'1.0.31');wp_enqueue_style('tbs-performance');wp_add_inline_style('tbs-performance',$css);
},1000);
add_filter('wpseo_metadesc',function($description){return is_front_page()&&!$description?'Découvrez Terre Brute Atelier aux Chartrons à Bordeaux : initiations au tour et au modelage, stages, cycles et cartes cadeaux dès 55 €.':$description;});
// Les titres sont enregistrés dans Yoast, sans surcharge permanente.
add_action('admin_init',function(){
 if(!current_user_can('manage_options')||get_option('tbs_perf_version')==='1.0.31')return;
 if(function_exists('w3tc_flush_all'))w3tc_flush_all();
 update_option('tbs_perf_version','1.0.31');
});
