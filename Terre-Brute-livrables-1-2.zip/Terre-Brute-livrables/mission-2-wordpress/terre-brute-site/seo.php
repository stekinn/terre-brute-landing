<?php
/** Corrections SEO : valeurs persistées dans Yoast et contenus Gutenberg éditables. */
if (!defined('ABSPATH')) exit;
function tbs_seo_items(){return (array)json_decode(file_get_contents(__DIR__.'/seo-metadata.json'),true);}
function tbs_seo_post($path){
 if($path==='')return get_post((int)get_option('page_on_front'));
 $slug=basename($path);$type=strpos($path,'2026/')===0?'post':(strpos($path,'atelier/')===0?'tb_atelier':(strpos($path,'produit/')===0?'product':'page'));
 return get_page_by_path($slug,OBJECT,$type);
}
function tbs_seo_meta($id,$key,$value){if(class_exists('WPSEO_Meta'))WPSEO_Meta::set_value($key,$value,$id);else update_post_meta($id,'_yoast_wpseo_'.$key,wp_slash($value));}
function tbs_seo_context_offer($slug){
 if(in_array($slug,array('tour-ou-modelage','premier-cours-poterie','erreurs-debutant'),true))return array('atelier/initiation-au-tour/','Découvrir l’initiation au tour à Bordeaux');
 if(in_array($slug,array('bol-pince','modelage-colombin','modelage-plaque','textures-ceramique'),true))return array('atelier/initiation-au-modelage/','Découvrir l’initiation au modelage à Bordeaux');
 if(in_array($slug,array('cycle-ceramique-progresser','carnet-inspiration'),true))return array('atelier/cycle-trimestriel/','Explorer le cycle de huit séances');
 if($slug==='preparer-stage-ceramique')return array('atelier/stage-week-end/','Découvrir le stage de deux jours');
 if($slug==='offrir-atelier-ceramique-bordeaux')return array('cartes-cadeaux/','Choisir une carte cadeau céramique');
 if($slug==='atelier-ceramique-equipe')return array('entreprises-groupes/','Préparer un atelier pour votre équipe');
 return null;
}
add_action('admin_menu',function(){add_management_page('SEO Terre Brute','SEO Terre Brute','manage_options','tbs-seo',function(){
 if(!current_user_can('manage_options'))return;$items=tbs_seo_items();$done=(array)get_option('tbs_seo_applied',array());
 echo '<div class="wrap"><h1>Corrections SEO Terre Brute</h1><p>Titres, descriptions et partage social enregistrés dans Yoast, sans remplacement des accroches visuelles. Les anciennes valeurs sont conservées dans une sauvegarde interne.</p><p><strong>'.count($done).' / '.count($items).' pages traitées</strong></p>';
 if(count($done)<count($items)){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="tbs_seo_apply">';wp_nonce_field('tbs_seo_apply');submit_button('Appliquer le prochain lot de corrections SEO');echo '</form>';}
 else echo '<p>Les 34 pages sont traitées. Pour modifier ensuite : éditez la page, puis ouvrez le panneau Yoast SEO.</p>';
 $errors=(array)get_option('tbs_seo_errors',array());if($errors)echo '<p>À vérifier : '.esc_html(implode(', ',$errors)).'</p>';
 echo '<p>Les prix, stocks, créneaux, coordonnées et avis ne sont pas modifiés. Les originaux des images restent dans la médiathèque.</p></div>';
 });});
add_action('admin_post_tbs_seo_apply',function(){
 if(!current_user_can('manage_options'))wp_die('Accès refusé');check_admin_referer('tbs_seo_apply');
 $items=tbs_seo_items();$done=(array)get_option('tbs_seo_applied',array());$backup=(array)get_option('tbs_seo_backup_20261029',array());$errors=array();$count=0;
 foreach($items as $item){$key=$item['path'];if(in_array($key,$done,true))continue;if($count>=5)break;$p=tbs_seo_post($key);if(!$p){$errors[]=$key;continue;}$id=$p->ID;
  if(!isset($backup[$id])){$backup[$id]=array('title'=>$p->post_title,'content'=>$p->post_content,'excerpt'=>$p->post_excerpt,'meta'=>array());foreach(array('title','metadesc','opengraph-title','opengraph-description','twitter-title','twitter-description','is_cornerstone') as $m)$backup[$id]['meta'][$m]=get_post_meta($id,'_yoast_wpseo_'.$m,true);update_option('tbs_seo_backup_20261029',$backup,false);}
  foreach(array('title'=>$item['title'],'metadesc'=>$item['description'],'opengraph-title'=>$item['title'],'opengraph-description'=>$item['description'],'twitter-title'=>$item['title'],'twitter-description'=>$item['description']) as $m=>$v)tbs_seo_meta($id,$m,$v);
  $update=array('ID'=>$id);
  if($key==='')$update['post_title']='Terre Brute Atelier : céramique à Bordeaux';
  if($p->post_type==='post'){
   $content=$p->post_content;$byline='<!-- wp:paragraph {"className":"tbs-editorial-byline"} --><p class="tbs-editorial-byline">Par <a href="'.esc_url(tbs_url('le-lieu')).'">l’équipe Terre Brute Atelier</a> / Céramique aux Chartrons, Bordeaux.</p><!-- /wp:paragraph -->';
   if(strpos($content,'tbs-editorial-byline')===false)$content=$byline.$content;
   $offer=tbs_seo_context_offer($p->post_name);if($offer&&strpos($content,'tbs-context-offer')===false)$content.='<!-- wp:paragraph {"className":"tbs-context-offer"} --><p class="tbs-context-offer"><a href="'.esc_url(home_url('/'.$offer[0])).'">'.esc_html($offer[1]).' →</a></p><!-- /wp:paragraph -->';
   $update['post_content']=$content;update_post_meta($id,'_tbs_editorial_team_author','1');
   if($p->post_name==='debuter-ceramique-guide')tbs_seo_meta($id,'is_cornerstone','1');
  }
  // Éviter une sauvegarde de contenu inutile pour les pages dont seules les metas changent.
  if(count($update)>1){$result=wp_update_post(wp_slash($update),true);if(is_wp_error($result)){$errors[]=$key;continue;}}
  clean_post_cache($id);
  $done[]=$key;$count++;update_option('tbs_seo_applied',$done,false);
 }
 update_option('tbs_seo_errors',$errors,false);if(function_exists('w3tc_flush_all'))w3tc_flush_all();wp_safe_redirect(admin_url('tools.php?page=tbs-seo'));exit;
});
// Identité de l’équipe cohérente avec la signature visible, sans compte utilisateur ajouté.
add_filter('wpseo_schema_graph',function($graph){
 if(!is_array($graph))return $graph;$orgid=home_url('/#organization');$hasorg=false;$id=get_queried_object_id();$team=is_singular('post')&&get_post_meta($id,'_tbs_editorial_team_author',true);
 foreach($graph as $piece){$types=(array)($piece['@type']??array());if(in_array('Organization',$types,true)){$orgid=$piece['@id'];$hasorg=true;break;}}
 if(!$hasorg)$graph[]=array('@type'=>'Organization','@id'=>$orgid,'name'=>get_bloginfo('name'),'url'=>home_url('/'));
 $out=array();foreach($graph as $piece){$types=(array)($piece['@type']??array());
  if(in_array('WebSite',$types,true))$piece['publisher']=array('@id'=>$orgid);
  if(in_array('WebPage',$types,true)&&is_front_page()){$name=get_post_meta($id,'_yoast_wpseo_title',true);$desc=get_post_meta($id,'_yoast_wpseo_metadesc',true);if($name)$piece['name']=$name;if($desc)$piece['description']=$desc;}
  if($team&&(in_array('Article',$types,true)||in_array('WebPage',$types,true))){$piece['author']=array('@id'=>$orgid);if(in_array('Article',$types,true))$piece['publisher']=array('@id'=>$orgid);}
  if($team&&in_array('Person',$types,true)&&($piece['name']??'')==='admin')continue;
  $out[]=$piece;
 }
 return $out;
},30);
// Le template commercial personnalisé n’appelle pas le bloc produit WooCommerce natif.
// Ajouter son balisage avec les données réelles du produit, sans prix codé en dur.
add_action('wp_footer',function(){
 if(!function_exists('is_product')||!is_product()||!function_exists('wc_get_product'))return;$p=wc_get_product(get_queried_object_id());if(!$p||!in_array($p->get_id(),array_map('intval',(array)get_option('tbs_gift_ids',array())),true))return;
 $data=array('@context'=>'https://schema.org','@type'=>'Product','@id'=>get_permalink($p->get_id()).'#product','name'=>$p->get_name(),'url'=>get_permalink($p->get_id()),'description'=>get_post_meta($p->get_id(),'_yoast_wpseo_metadesc',true),'brand'=>array('@type'=>'Brand','name'=>get_bloginfo('name')),'offers'=>array('@type'=>'Offer','url'=>get_permalink($p->get_id()),'priceCurrency'=>get_woocommerce_currency(),'price'=>(string)wc_get_price_to_display($p),'availability'=>$p->is_in_stock()?'https://schema.org/InStock':'https://schema.org/OutOfStock','seller'=>array('@id'=>home_url('/#organization'))));
 $image=wp_get_attachment_image_url($p->get_image_id(),'large');if($image)$data['image']=array($image);
 echo '<script type="application/ld+json">'.wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP).'</script>';
},25);
