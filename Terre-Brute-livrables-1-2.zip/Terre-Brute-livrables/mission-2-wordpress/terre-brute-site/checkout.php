<?php
if(!defined('ABSPATH'))exit;
add_action('wp_enqueue_scripts',function(){if(function_exists('is_checkout')&&is_checkout()&&!is_order_received_page())wp_enqueue_style('tbs-checkout',plugins_url('checkout.css',__FILE__),array('tb-site'),'1.0.38');},130);
add_action('woocommerce_before_checkout_form',function(){
 echo '<div class="tbs-checkout-intro"><p class="tbs-eyebrow">VOTRE PARENTHÈSE PREND FORME</p><h2>Encore un instant,<br>et c’est à vous.</h2><p>Retrouvez votre sélection, renseignez vos coordonnées et confirmez votre commande sur cette même page.</p><ol class="tbs-checkout-steps" aria-label="Votre parcours"><li>Sélection choisie</li><li aria-current="step">Coordonnées et paiement</li><li>Confirmation par e-mail</li></ol></div>';
},5);
