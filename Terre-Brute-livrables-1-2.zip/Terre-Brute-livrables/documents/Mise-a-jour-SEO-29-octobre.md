# Corrections SEO appliquées dans WordPress

29 octobre 2026 / Extension Terre Brute Site 1.0.33.

## Réalisé et vérifié

* 34 titres SEO et 34 descriptions enregistrés dans les champs Yoast : accueil, catalogue, pages principales, 4 ateliers, 20 articles et 3 cartes cadeaux.
* Titres et descriptions de partage Open Graph / Twitter alignés avec ces valeurs. Ils restent éditables dans Yoast, sans surcharge permanente des titres.
* Description supplémentaire du template désactivée lorsque Yoast est actif : une seule meta description par page.
* Accueil : suppression de « version modifiable » dans le titre social et le nom WebPage du JSON-LD. L’accroche visuelle est conservée.
* 20 articles : signature visible « l’équipe Terre Brute Atelier » dans un paragraphe Gutenberg, avec lien vers le lieu. Auteur Article cohérent via une Organization, sans création de compte ni modification des accès.
* Guide principal marqué comme contenu essentiel dans Yoast. Liens contextuels vers les offres adaptées ajoutés aux articles concernés, en plus du maillage existant.
* Identité Organization reliée au site. Aucun numéro de téléphone, adresse de rue ou avis inventé.
* Fiches des 3 cartes cadeaux : un Product/Offer par page, prix, devise et disponibilité issus de WooCommerce. Pas de notation ajoutée.
* Sauvegarde interne des valeurs SEO et contenus précédents avant modification ; copie du code précédent en local.
* Règles de permaliens régénérées sans modifier la structure des URL.

## Contrôles après publication

Les 34 URL ont été revisitées et comparées au tableau attendu : 34/34 titres, descriptions et valeurs Open Graph conformes. Une seule description et un H1 sur chaque page contrôlée. Signatures visibles sur 20/20 articles. Un Product par fiche cadeau (55 €, 180 €, 390 €). Code PHP contrôlé avant déploiement ; le traitement par lots initial a été corrigé après une interruption sur la page boutique. Les 34 pages sont ensuite traitées sans erreur signalée.

Le design de l’accueil, les prix, stocks et dates ne sont pas modifiés. Aucune transaction ou inscription newsletter n’a été créée dans cette recette. Les paiements restent en mode test. Les métadonnées produits décrivent l’offre ; l’information de paiement test demeure dans le parcours.

## Search Console

Le sitemap `/sitemap_index.xml` a été envoyé. Après un état transitoire « impossible de récupérer », il apparaît comme « Index de sitemaps / Opération effectuée / 29 octobre 2026 ». Le nombre de pages découvertes est encore 0 au contrôle : la présence de chaque page dans le sitemap et sa découverte par Google restent à confirmer. L’ancien `/wp-sitemap.xml` reste enregistré avec 41 pages découvertes.

La demande d’indexation du guide a été tentée, mais Google répond « Quota dépassé : quota quotidien ». Elle n’a donc pas été acceptée. Ne pas compter les cartes cadeaux comme soumises : la demande identique n’a pas été répétée après ce refus. Réessayer demain pour le guide et la page cartes cadeaux. Les tests précédents confirmaient l’accès de Google aux cartes cadeaux ; ils ne garantissent pas son indexation finale.

## Restant de l’audit

* SEO-01 : suivi de découverte et demandes d’indexation après réinitialisation du quota.
* SEO-08 : compléter les programmes et les modalités réellement incluses (matières, cuissons, récupération) lorsque ces informations sont validées. Aucun engagement commercial inventé.
* SEO-09 : adresse exacte et preuves d’avis à confirmer avant une exploitation réelle. Organization ajoutée, sans LocalBusiness incomplet ni adresse fictive.
* SEO-10 : balisage Product ajouté et contrôlé dans le DOM ; une validation Google complète des résultats enrichis reste à faire.
* SEO-11 : enrichissement photo des tutoriels et examen éditorial des images décoratives / informatives. Les alt vides ne sont pas modifiés automatiquement.
* Pas de pentest, de plan de maintenance ni d’audit WAVE/EcoIndex effectué dans cette étape SEO.

Les fichiers d’audit originaux décrivent l’état avant correction. `pages-apres-correction.json` et les captures `*-apres.png` constituent les preuves de cette mise à jour.
