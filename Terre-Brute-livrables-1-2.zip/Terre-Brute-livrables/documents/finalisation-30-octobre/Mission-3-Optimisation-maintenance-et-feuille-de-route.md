# Optimiser et piloter Terre Brute

## Périmètre de preuve

État établi à partir des contrôles du site et des rapports conservés. Les scores Lighthouse portent sur l’accueil le 29 octobre, avant le dernier ajustement du chatbot. Ils ne décrivent pas automatiquement toutes les pages ni la version finale. Aucun chiffre de vente réel n’est revendiqué.

## Ancien site du brief / nouveau site mesuré

Performance mobile : 38 / 82. Accessibilité Lighthouse : 61 / 100. SEO Lighthouse : 72 / 100. Bonnes pratiques : 70 / 100. LCP mobile : 5,4 s / 4,3 s. Ordinateur : performance 99, LCP 0,9 s. Les objectifs de score sont atteints sur cette mesure ; l’objectif LCP inférieur à 2,5 s reste non atteint.

## Comparaison technique avant intervention / après

Mesures comparables du 29 octobre : performance mobile 69 à 82 ; ordinateur 86 à 99. LCP mobile 14,6 à 4,3 s. Le point de départ 38 est un chiffre fourni par le brief, pas une mesure que nous avons réalisée sur Wix.

## Preuves et limites

Rapport : https://pagespeed.web.dev/analysis/https-terre-brute-atelier-rf-gd/4mlot8r8qk?form_factor=mobile . Détails : outputs/audit-performance/Bilan-performance-29-octobre.md. WAVE et EcoIndex distants ont renvoyé une page incomplète liée à l’hébergement : résultats non exploitables. Audit axe et poids final à compléter. HTML et CSS de la landing statique : zéro erreur W3C le 30 octobre (deux avertissements CSS). Lighthouse 100 ne prouve pas une conformité WCAG AA complète.

# Performance et accessibilité

## Optimisations appliquées

Photos WebP avec variantes de taille, srcset, dimensions explicites et chargement différé sous le premier écran. Texture terre optimisée. Fraunces et Inter hébergées localement. Styles de l’accueil regroupés ; ressources WooCommerce conservées sur les pages commerciales.

## Changement demandé sur Terra

Terra affiche désormais directement les boutons texte et voix. Son SDK est donc chargé automatiquement sur les pages où elle est présente. Le microphone ne démarre jamais automatiquement. Cette modification invalide l’hypothèse du dernier audit où ElevenLabs ne se chargeait qu’au clic : refaire PageSpeed avant d’afficher un score final.

## Garder le site rapide après remise

Jeanne prépare une image autour de 1600 px maximum, compressée, avant téléversement. Vérifier la miniature et l’alternative dans la médiathèque. Une automatisation de conversion des nouveaux originaux n’est pas démontrée : prévoir un outil ou une procédure de compression. Ne pas importer directement les originaux de 6 à 12 Mo du brief.

## Recette accessible mensuelle

Clavier : atteindre navigation, offres, formulaire et FAQ sans souris. Vérifier focus, libellés, erreurs et absence de piège clavier. Contrôler zoom à 200 %, affichage 320 px, contraste des textes et alternatives des images utiles. Ne pas utiliser le céladon pour du texte. Refaire axe/WAVE après toute modification des formulaires.

# SEO technique et local

## Appliqué

34 titres et descriptions Yoast, valeurs sociales alignées, suppression des descriptions en double, signature des 20 articles, guide principal déclaré contenu essentiel, liens vers les offres, données Product/Offer pour les trois cadeaux et schéma Organization. URL lisibles et sitemap XML envoyé à Search Console.

## Cinq requêtes locales prioritaires

1. atelier poterie Bordeaux : page Ateliers. 2. cours céramique Chartrons : accueil / lieu. 3. initiation tour potier Bordeaux : fiche tour. 4. carte cadeau atelier céramique Bordeaux : landing cadeaux. 5. team building poterie Bordeaux : Entreprises et groupes. Priorités basées sur les intentions du brief, sans volumes de recherche inventés.

## Cinq actions Google Business Profile

1. Informations nom, adresse et téléphone cohérentes avec le site, uniquement après validation des coordonnées. 2. Catégorie principale et services décrivant réellement l’atelier. 3. Horaires normaux et exceptions mis à jour. 4. Photos originales du lieu, de l’équipe et des ateliers. 5. Lien de réservation balisé UTM et réponse personnalisée aux avis authentiques. Ne pas créer une fiche publique pour une entreprise fictive : la maquette de fiche sert à la soutenance.

## À finaliser

Le brief exige LocalBusiness. Organization ne le remplace pas. L’adresse exacte n’étant pas fournie, ne pas inventer rue, téléphone ou coordonnées. Préparer le schéma puis le publier quand les informations sont validées. Suivre la découverte du sitemap ; la demande d’indexation avait été refusée pour quota quotidien. Vérifier les produits dans Rich Results Test.

# Sécurité et maintenance mensuelle

## État à distinguer du plan

HTTPS utilisé. Loginizer et Loginizer Pro sont présents dans l’administration ; leur présence ne prouve pas que chaque protection soit activée. Formulaires : nonce, nettoyage des champs, honeypot et limitation de fréquence dans le code. Stripe reste en TEST. La méthode OTP par application est activée ; le compte administrateur doit encore être associé personnellement à une application. UpdraftPlus est installé : fichiers hebdomadaires (2 copies), base quotidienne (7 copies). La première sauvegarde a échoué avec une réponse inattendue : aucune archive complète ni restauration validée.

## Avant mise à jour / responsable administrateur / 10 min

Créer une sauvegarde des fichiers et de la base, vérifier qu’elle se télécharge et relever version/date. Conserver une copie privée hors serveur. Mettre à jour d’abord sur une copie de test ; ne pas lancer une mise à jour majeure pendant la soutenance. En cas d’erreur : restaurer fichiers et base de la même date.

## Chaque mois / administrateur / 15 min

Lire les alertes de sécurité et versions. Vérifier limitation des connexions et 2FA. Revoir les comptes et rôles, supprimer les accès devenus inutiles par une procédure approuvée. Installer les correctifs après sauvegarde et contrôler ensuite accueil, filtres, panier, Stripe TEST et e-mails.

## Chaque mois / Jeanne / 15 min

Contrôler les prochaines dates, capacités, tarifs et liens. Faire une réservation de test et vérifier l’e-mail. Contrôler l’inscription newsletter et la désinscription. Vérifier qu’aucun secret, témoignage non vérifié ou donnée personnelle n’est publié.

## Chaque mois / référent web / 10 min

Relever erreurs Search Console, LCP, événements GA4 et quotas ElevenLabs/Gmail. Noter une amélioration prioritaire et sa preuve. Total mensuel cible : 50 min. Une alerte de sécurité urgente se traite immédiatement, sans attendre ce créneau.

## Sauvegardes et restauration

Cible : base quotidienne, fichiers hebdomadaires et avant chaque changement ; 7 bases et 2 copies de fichiers au minimum, dont une hors serveur. Une programmation dépendant de WP-Cron doit être surveillée. Tester une restauration sur une copie locale trimestriellement. La réussite réelle de ces opérations doit être consignée, pas supposée.

# Mesurer les conversions utiles

## Installation

GA4 G-401JF4629T via GTM-WQT7FCP6. Pays France, devise EUR. Google est chargé après consentement seulement. Refuser et Accepter disponibles, choix modifiable. URL et référent sans paramètres ; aucun nom, e-mail, message ou donnée bancaire transmis par le marquage personnalisé.

## Parcours suivi

page_view : consultation. cta_click : CTA avec cta_name et cta_location. view_item : fiche produit. add_to_cart : ajout réussi. begin_checkout : arrivée au paiement. purchase : commande payée et référence de transaction. Les tests Stripe portent test_mode=true. Les clics et ajouts ont été observés dans GA4 ; le prochain achat TEST doit valider purchase.

## Demande de devis

Conversion attendue : generate_lead après enregistrement réussi d’un devis, lead_type=devis. Ne jamais compter le simple clic sur Envoyer comme une demande reçue. Paramètres exclus : entreprise, nom, e-mail, date privée et texte de la demande. Cette conversion reste à déployer et tester dans la version auditée ici.

## Tableau de pilotage

Réservation : commandes ateliers payées / sessions pertinentes. Cadeau : commandes cadeaux payées / sessions landing. Abandon : arrivées au paiement sans achat, avec limites de consentement et de navigation entre appareils. Devis : demandes enregistrées / visites Entreprises. Le taux de clic d’un CTA nécessite aussi une mesure de son exposition ; ne pas appeler CTR un simple rapport clics/pages sans préciser le dénominateur.

## Objectifs métier

60 % des réservations en ligne à fin mars 2027 ; charge administrative 7 à 3 h/semaine ; absences 15 à moins de 5 % ; 150 cadeaux sur la campagne de Noël. Ce sont des objectifs du brief, pas des résultats atteints. Les données du site de démonstration ne prouvent pas ces gains.

# Feuille de route sur trois mois

## Novembre / fiabiliser et lancer

Semaine 1 : finaliser sauvegarde/restauration, droits éditeur, audit accessible, LocalBusiness si coordonnées validées, achat et devis mesurés. Semaine 2 : vérifier mobile avec cinq utilisateurs découvrant le site, objectif réservation en moins de deux minutes et trois étapes principales. Semaines 3-4 : surveiller stocks, mails, indexation, erreurs et campagne cadeaux. Responsable : référent web avec Jeanne.

## Décembre / améliorer la conversion cadeau

Comparer mobile/desktop, sources Instagram et Google, clics et abandon du paiement. Améliorer le LCP, vérifier les quotas mails et Terra, corriger les questions récurrentes. Publier un contenu utile par semaine. Ne pas multiplier les changements simultanés pendant une expérimentation.

## Test A/B argumenté

Hypothèse : préciser la validité et le prix près du CTA réduit l’incertitude. A : Offrir un atelier. B : Offrir un atelier / dès 55 €, valable un an. Même emplacement, palette et destination, répartition aléatoire 50/50 stable, uniquement après consentement. Mesure principale : achats cadeaux payés par session de la landing. Secondaires : clic CTA, abandon paiement, revenu par session. Garde-fous : performance et erreurs.

## Décider sans surinterpréter

Fixer durée et taille d’échantillon avant lancement à partir du taux de conversion réel, actuellement inconnu. Couvrir au moins deux semaines et les mêmes jours. Ne pas déclarer gagnant après quelques ventes ni arrêter au premier résultat favorable. Si trafic insuffisant, rapporter une tendance et compléter par des entretiens ; ne pas promettre de significativité.

## Janvier / nouvel espace et autonomie

Ajouter l’espace de 90 m² et ses capacités réelles, offres groupes et stages. Vérifier les règles de réservation, former Jeanne à l’ajout d’une date et Clémence aux articles/photos. Faire un exercice de restauration et revoir les accès. Prioriser ensuite une liste d’attente, utile mais facultative dans le brief.
