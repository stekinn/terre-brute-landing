# Journal d’usage de l’IA

## Méthode et honnêteté

Reconstitution le 30 octobre 2026 à partir de la conversation et des sources présentes. Ce document n’est pas un relevé exhaustif tenu en temps réel. L’utilisatrice doit relire et compléter les demandes exactes et son appréciation personnelle avant remise.

## Conception et identité

Outil : Codex et génération d’images. Demande : construire un site Terre Brute cohérent avec le brief, texture terre, crème/argile, Fraunces/Inter, pages modifiables. Gardé : structure des pages et palette. Corrigé : boutons noirs, fonds bleus/jaunes, espacements, images floues et doublons. Rejeté : écrans intermédiaires inutiles. Ne pas inclure le projet MŌMI abandonné dans les livrables Terre Brute.

## Code et WordPress

Outil : Codex. Demande : landing HTML/CSS/JS, simulateur et FAQ, type Ateliers, réservation datée, stocks, cadeaux un an, formulaires. Gardé : fichiers natifs et WooCommerce. Corrigé : date obligatoire sauf cadeaux, parcours paiement direct, validation des quantités et créneaux, bloc simulateur en double. Vérifications : analyse syntaxique PHP/JS et contrôles de parcours ; ne pas confondre syntaxe correcte et absence de toute erreur.

## Contenus et médias

Outil : Codex et génération de visuels. Demande : 20 articles avec guide principal, avis/personas, images de publications Instagram. Gardé : contenus adaptés au ton de la marque. À relire : exactitude des conseils de céramique, programmes et engagements commerciaux. Les témoignages et visuels de maquette ne sont pas des preuves d’avis réels ni de fréquentation.

# Contrôles et apprentissages

## Performance, SEO et mesure

Codex a aidé à convertir les images, héberger les polices localement, différer des scripts, renseigner Yoast et configurer GA4/GTM. Gardé : corrections vérifiées et plan de marquage. Corrigé : descriptions en double, titres sociaux incohérents et événements de test. Limites consignées : LCP mobile encore supérieur à la cible, indexation non garantie, nouvelle mesure nécessaire après chargement direct de Terra.

## Mails et assistant

Codex a aidé au transport Gmail, aux messages dans la DA, au double opt-in et à Terra texte/voix. Resend n’a pas été retenu pour l’envoi final faute de domaine expéditeur vérifié. Tests écrits de Terra réalisés ; essai vocal personnel reporté. L’IA ne valide pas une réservation et ne doit pas recevoir de données sensibles.

## Ce que je dois savoir expliquer au jury

HTML : sections, titres, labels et structure sémantique. CSS : Grid/Flexbox, variables de couleur et media queries. JavaScript : événements input/change/submit, conversion d’un nombre, validation 1 à 8, prix multiplié par participants, formatage EUR et aria-expanded. WordPress : type de contenu, taxonomie, produit-créneau, stock, rôle éditeur, shortcode et métadonnées.

## Exercice de préparation

Ouvrir gift.js et expliquer le calcul ligne par ligne. Modifier une quantité invalide et observer l’erreur. Parcourir la FAQ au clavier. Ajouter une date avec le compte éditeur puis vérifier sa présence publique. Expliquer pourquoi un paiement test n’est pas du chiffre d’affaires et pourquoi un score Lighthouse ne certifie pas WCAG. Ne pas prétendre maîtriser une portion de code qui n’a pas été relue.
