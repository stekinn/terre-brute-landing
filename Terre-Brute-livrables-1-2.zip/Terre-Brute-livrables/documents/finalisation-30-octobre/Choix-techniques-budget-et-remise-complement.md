# Choix techniques et budget / complément

## Architecture et domaine

WordPress : https://terre-brute-atelier.rf.gd/ . Landing statique : https://stekinn.github.io/terre-brute-landing/cartes-cadeaux.html . GitHub : https://github.com/stekinn/terre-brute-landing . Hébergement de démonstration InfinityFree gratuit, sans achat. Le domaine terrebrute-atelier.fr mentionné dans le brief n’est pas connecté à cette démonstration.

## Administration plutôt que mise en page manuelle

Le thème Twenty Twenty-Five et Gutenberg portent les contenus éditoriaux. Ateliers est un type de contenu avec champs et taxonomies. Une extension dédiée génère les listes, formulaires et offres depuis les données. WooCommerce stocke produits, créneaux, stocks et commandes. Les contenus restent éditables ; changer la structure PHP/CSS demande un administrateur ou développeur.

## Extensions utiles / rôle et justification

Terre Brute Landing 1.1.4 : styles et landing de base. Terre Brute Site et ateliers : contenus structurés et parcours métier. WooCommerce : commandes, produits et stocks. WooCommerce Stripe Gateway : paiement TEST officiel. Yoast SEO : métadonnées et sitemap éditables. FluentSMTP : transport Gmail API. W3 Total Cache : cache et optimisation. Loginizer + Pro : protection des connexions, activation des fonctions à contrôler. Site Kit : intégration Google installée, ne pas dupliquer GA4 déjà posé par GTM. Resend est inactif : remplacé par Gmail. UpdraftPlus ajouté pour sauvegarde/export, succès à vérifier dans la recette finale.

## Coûts et dépendances

Les extensions libres sont utilisées sans achat dans ce projet. La provenance/licence de Loginizer Pro doit être confirmée par le titulaire du compte. Les limites gratuites Gmail/ElevenLabs et de l’hébergement sont à surveiller. Aucun devis fournisseur ni abonnement payant n’a été souscrit. Les secrets et mots de passe restent hors GitHub.

# Budget proposé et remise des clés

## Investissement initial / enveloppe du brief 6 000 €

Conception et maquettes : 1 400 €. Intégration et WordPress : 2 400 €. Contenus et SEO : 600 €. Recette, accessibilité, sécurité et optimisation : 800 €. Formation et documentation : 500 €. Réserve : 300 €. Total : 6 000 €. Répartition pédagogique proposée, pas des dépenses facturées.

## Fonctionnement / plafond 60 € par mois

Enveloppes prévisionnelles : hébergement 15 €, domaine 2 €, sauvegarde externalisée 5 €, assistant/mailing 10 €, réserve 8 € : total 40 €/mois, marge 20 €. Ce sont des plafonds d’allocation, pas des tarifs actuels vérifiés ni des achats. La démonstration utilise les plans gratuits ; l’exploitation réelle nécessiterait des devis adaptés au trafic et à la disponibilité souhaitée.

## Rôles

Jeanne : compte éditeur dédié pour pages, articles, ateliers et produits autorisés ; pas de gestion des extensions ou du thème. Administrateur : réglages sensibles, mises à jour, sauvegardes et intégrations. Le guide décrit l’ajout d’une date, un article avec photo et la modification d’un prix cadeau. L’épreuve décisive reste une manipulation par un tiers en suivant uniquement ce guide.

## Plan B et remise

Fournir URL WordPress, landing, Figma et GitHub, accès éditeur privé, guide de cinq pages maximum, audits, plan de maintenance, plan de marquage, feuille de route et journal IA. Ajouter une vraie sauvegarde des fichiers et de la base ; le ZIP de l’extension ne suffit pas. Ne jamais joindre le dump de base ou les clés dans un dépôt public.

## Comprendre les limites

Carte cadeau : la référence permet au bénéficiaire de contacter l’atelier dans l’année ; pas de moteur automatique de bon cadeau à code unique démontré. Terra répond mais ne lit pas les stocks et ne réserve pas. Les maquettes Figma sont issues d’un import vectoriel : vérifier dimensions, polices et fidélité avant remise.
