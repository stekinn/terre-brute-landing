# Terre Brute Atelier / Référence PageSpeed

Rapport fourni par l’utilisateur : 28 octobre 2026 à 23 h 15 (Europe/Paris).
Consultation : 29 octobre 2026. Ce rapport précède l’intégration de Terra réalisée le 29 octobre ; il n’est pas une mesure de la version actuelle.

Source : https://pagespeed.web.dev/analysis/https-terre-brute-atelier-rf-gd/acwly1xkf6?hl=fr

| Mesure | Mobile | Desktop |
|---|---:|---:|
| Performances | 61 | 84 |
| First Contentful Paint | 3,2 s | 0,8 s |
| Largest Contentful Paint | 12,5 s | 2,8 s |
| Total Blocking Time | 0 ms | 0 ms |
| Cumulative Layout Shift | 0,178 | 0,006 |
| Accessibilité automatique | 100 | 100 |
| Bonnes pratiques | 96 | 96 |
| SEO | 85 | 92 |

Aucune donnée terrain utilisateur disponible dans le rapport. Les mesures sont des essais Lighthouse en laboratoire ; mobile utilise une émulation Moto G Power et une connexion 4G lente.

## Éléments observés

- Économies images estimées : 2091 Kio mobile, 2322 Kio desktop.
- Image pexels-eyupbeyhan-16428207.jpg : 1821 Kio, 4160 × 6240 pixels, affichée autour de 366 × 549 pixels dans le rapport desktop.
- Photos de tournage et de décoration de tasse : sélections de tailles trop grandes, attribut sizes proche de la largeur totale au lieu de la largeur des cartes.
- Requêtes de blocage du rendu : économies estimées 2520 ms mobile, 630 ms desktop. CSS WooCommerce, feuilles Terre Brute, jQuery et Google Fonts apparaissent dans la liste.
- Décalage mobile : le conteneur main est signalé ; Inter et Fraunces apparaissent comme polices Web liées au décalage.
- Élément LCP signalé : titre sur desktop ; texte de présentation sur mobile. Ne pas supposer qu’il s’agit d’une photo de la bannière.
- Meta description absente. robots.txt : délai de récupération dépassé sur mobile, sans preuve que son contenu soit syntaxiquement invalide.

## Ordre de correction proposé

1. Produire des variantes WebP/AVIF adaptées aux cartes et corriger srcset/sizes. Dimensions explicites et chargement différé sous la ligne de flottaison. Préserver la netteté de la texture et des photos.
2. Héberger localement les polices WOFF2 utiles, donner la priorité aux fichiers critiques et ajuster les polices de secours pour limiter les décalages. Réserver l’espace du bandeau et des images.
3. Charger les ressources WooCommerce selon le contexte, en conservant les fonctions nécessaires au panier. Réduire le chemin CSS critique ; ne pas différer les styles essentiels sans contrôle visuel.
4. Charger ElevenLabs au clic sur un lanceur léger, plutôt qu’au chargement de chaque page. Différer la carte interactive jusqu’à proximité de la section ou à son ouverture.
5. Vérifier le cache existant et la compression sans multiplier les extensions. Exclure panier, paiement, compte et sessions personnalisées du cache public.
6. Ajouter la meta description dans Yoast et vérifier séparément la disponibilité de robots.txt.

## Recette à venir

Aucune optimisation n’a été déployée lors de cette lecture du rapport. Faire une mesure actuelle avant intervention, puis comparer après modifications sur la même URL et les mêmes modes mobile/desktop, idéalement plusieurs passages. Vérifier la navigation, le panier, Stripe TEST, les formulaires et Terra après changement de ressources. Les gains estimés ne constituent pas une promesse de score.
