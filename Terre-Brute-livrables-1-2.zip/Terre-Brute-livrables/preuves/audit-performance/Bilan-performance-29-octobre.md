# Optimisation WordPress : audit avant / après

Site : https://terre-brute-atelier.rf.gd/
Date : 29 octobre 2026. Version déployée : Terre Brute Site 1.0.31.

## Mesures comparables

Mesures Lighthouse PageSpeed, chargement initial, conditions de laboratoire. Aucune donnée de terrain CrUX disponible. Les scores peuvent varier entre deux exécutions.

| Indicateur | Mobile avant | Mobile après | Ordinateur avant | Ordinateur après |
|---|---:|---:|---:|---:|
| Performance | 69 | 82 | 86 | 99 |
| FCP | 3,2 s | 1,9 s | 0,8 s | 0,5 s |
| LCP | 14,6 s | 4,3 s | 2,5 s | 0,9 s |
| TBT | 0 ms | 0 ms | 0 ms | 0 ms |
| CLS | 0 | 0 | 0,006 | 0 |
| Accessibilité | 100 | 100 | 100 | 100 |
| Bonnes pratiques | 96 | 100 | 96 | 100 |
| SEO | 85 | 100 | 92 | 100 |

Avant (29 octobre 11:05:35) : https://pagespeed.web.dev/analysis/https-terre-brute-atelier-rf-gd/c3aim17yqi?form_factor=mobile
Après (29 octobre 11:21:57) : https://pagespeed.web.dev/analysis/https-terre-brute-atelier-rf-gd/4mlot8r8qk?form_factor=mobile
Version bureau : remplacer form_factor=mobile par form_factor=desktop.

Le rapport initial fourni du 28 octobre était à 61 / 84. La comparaison ci-dessus utilise une nouvelle mesure juste avant les modifications, avec le chatbot déjà intégré.

## Modifications déployées

* Photos WebP en quatre tailles (480, 768, 1200 et 1600 px), srcset et tailles d’affichage corrigées. Les originaux restent disponibles dans la médiathèque et les blocs restent modifiables.
* Dimensions explicites et chargement différé des photos de l’accueil sous le premier écran.
* Fond texturé optimisé en WebP, sans supprimer la texture.
* Polices Fraunces et Inter locales avec préchargement, suppression de l’appel Google Fonts.
* Regroupement des styles de l’accueil dans la page, suppression de plusieurs feuilles WooCommerce inutiles sur cet accueil. Les scripts du panier et les styles des pages commerciales sont conservés.
* Bouton Terra local : ElevenLabs est téléchargé seulement après ouverture de l’assistant. Le texte et la voix restent proposés, sans déclencher le microphone automatiquement.
* Titre SEO et meta description de l’accueil.
* Purge du cache après mise à jour.

## Vérifications

10 fichiers PHP analysés sans erreur de syntaxe. JavaScript du chargeur vérifié. Contrôle visuel de l’accueil après déploiement, couleurs crème et terre conservées. Photos servies en WebP. Aucun script ElevenLabs avant clic ; boutons texte et voix présents après ouverture. Simulateur : 2 personnes = 110 €. FAQ horaires ouverte correctement (mardi au samedi, 10 h à 19 h). Panier existant chargé avec sa carte cadeau à 55 €. Aucun paiement ou nouvel envoi d’e-mail effectué dans cette recette. La voix reste à tester avec le microphone par l’utilisatrice.

## Limites / suite

Le mobile progresse nettement mais le LCP reste à 4,3 s en connexion 4G lente. Le rapport indique encore environ 820 ms de blocage du rendu et 52 Kio d’économie d’images possible. Prochaine étape : profiler les ressources WordPress restantes et adapter plus finement le fond au mobile, puis vérifier les pages produit, contact et paiement séparément. Ne pas désactiver globalement WooCommerce ou différer ses dépendances sans recette du paiement.

Les résultats portent sur l’accueil ; ils ne constituent pas une mesure de toutes les pages ni une garantie de score constant.
