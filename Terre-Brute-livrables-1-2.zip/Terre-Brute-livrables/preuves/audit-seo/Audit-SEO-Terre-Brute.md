# Audit SEO : Terre Brute Atelier

**Date : 29 octobre 2026. Périmètre : 39 URL canoniques, dont 20 articles, 4 ateliers et 3 produits cadeaux ; un filtre de journal en complément.**

## Verdict

La structure est saine et l’accueil est indexé. La priorité porte sur la découverte des nouvelles pages par Google, la cohérence des métadonnées et la précision commerciale. Le score Lighthouse SEO de 100 concerne l’accueil et ne valide pas le référencement de tout le site.

L’audit est en lecture seule : aucune modification WordPress, aucun achat ni aucun envoi de formulaire. Les propositions jointes ne sont pas appliquées.

## Constats positifs

* 39 pages consultées : un H1, une URL canonique auto-référente et au moins une description sur chacune. Titres et canoniques distincts dans cet échantillon. Aucune page d’erreur visible sur les 39 destinations consultées.
* 20 articles présents ; le guide relie ses 19 articles complémentaires et chacun des 19 renvoie vers le guide. Tous les articles proposent un lien vers /ateliers/.
* Panier et paiement : noindex, follow. Les pages de contenu contrôlées autorisent l’indexation dans la balise robots.
* robots.txt consultable : pas de blocage général du site, protection des journaux et fichiers WooCommerce, sitemap Yoast déclaré.
* JSON-LD Article présent sur les 20 articles ; WebPage et BreadcrumbList présents. Aucun JSON-LD non analysable détecté dans les pages relevées. Cela ne remplace pas le test Google des résultats enrichis.
* Filtre /journal/?rubrique=Guides : canonique vers /journal/, ce qui évite de promouvoir une URL filtrée comme page indépendante.

## Ce que Google confirme

| Contrôle | Résultat observé |
|---|---|
| Accueil | URL sur Google ; page indexée ; exploration mobile réussie le 28/10/2026 à 12:51:55 ; canonique retenue = accueil |
| Sitemap envoyé | /wp-sitemap.xml : opération effectuée, dernière lecture 28/10/2026, 41 pages découvertes |
| Guide principal | Non indexé : Google ne reconnaît pas cette URL ; aucun sitemap référent détecté dans l’inspection |
| Cartes cadeaux | URL inconnue dans l’index ; test actif du 29/10 à 11:58 : Google a accès à cette URL, la page peut être indexée |
| Rapports globaux | Traitement des données en cours ; 0 clic affiché au moment du contrôle |

Les nouvelles pages datent du 28 octobre : une URL encore inconnue n’établit ni pénalité ni défaut d’indexabilité. La lecture du sitemap Yoast actuel /sitemap_index.xml n’a pas pu être vérifiée directement : le navigateur intégré a échoué sur ce XML, curl et le lecteur web n’ont pas obtenu de réponse exploitable. Le sitemap WordPress historique a en revanche bien été lu par Google. L’inspection de l’accueil mentionne aussi une erreur temporaire de traitement du sitemap : contrôler son état actuel après relecture.

## Corrections prioritaires

### SEO-01 / P1 : Découverte et indexation

**Périmètre :** Guide principal et cartes cadeaux.

**Preuve :** Search Console : « Google ne reconnaît pas cette URL » pour ces deux URL. Accueil indexé ; rapport global en traitement.

**Action :** Vérifier leur présence dans le sitemap actuel, tester le guide en direct et demander leur indexation après correction. Le test actif des cartes cadeaux est réussi : Google peut y accéder et la page peut être indexée. Recontrôler dans Search Console ; ne pas promettre un délai.

**Validation :** Indexation confirmée ou motif documenté pour les deux pages.

### SEO-02 / P1 : Description en double

**Périmètre :** /cartes-cadeaux/.

**Preuve :** Deux meta name="description", de 143 et 135 caractères.

**Action :** Conserver une seule source de métadonnées via Yoast ; supprimer la sortie supplémentaire du code personnalisé.

**Validation :** Une seule description et un seul titre cohérents dans le HTML rendu.

### SEO-03 / P1 : Partage social et schéma incohérents

**Périmètre :** Accueil.

**Preuve :** Le title est correct, mais og:title et WebPage.name contiennent « Offrir un atelier : version modifiable ». og:description reprend la navigation et un long extrait.

**Action :** Synchroniser titre SEO, description, titre social et nom de page du schéma depuis Yoast. Choisir une image de partage adaptée.

**Validation :** Aucune mention « version modifiable » dans les métadonnées ; aperçus sociaux cohérents.

### SEO-04 / P1 : Titres peu explicites pour la recherche

**Périmètre :** Catalogue, 4 ateliers, entreprises, lieu, contact, journal.

**Preuve :** Exemples : « Les mains dans la terre. » et « Premiers gestes au tour ». Ils distinguent mal la prestation et la localisation.

**Action :** Renseigner des titres SEO descriptifs sans remplacer nécessairement les accroches visuelles. Ajouter une précision de service dans le contenu visible.

**Validation :** Offre et localisation lisibles dans le titre des pages commerciales.

### SEO-05 / P1 : Descriptions de produits identiques

**Périmètre :** 3 fiches cartes cadeaux.

**Preuve :** Description identique : « Démonstration pédagogique. Aucun paiement réel. »

**Action :** Rédiger une description distincte par offre : formule, tarif, validité d’un an et réservation ultérieure. Conserver l’information de paiement test dans le parcours de démonstration.

**Validation :** Trois descriptions uniques et conformes à l’offre.

### SEO-06 / P2 : Descriptions éditoriales à rédiger

**Périmètre :** 20 articles et plusieurs pages principales.

**Preuve :** Les descriptions reprennent souvent le début du texte et se terminent au milieu d’une phrase.

**Action :** Rédiger une phrase autonome et précise par page, en reprenant son intention. Voir le CSV de propositions. La longueur n’est pas un critère de réussite absolu.

**Validation :** Descriptions uniques et compréhensibles, sans coupure de phrase.

### SEO-07 / P2 : Identité éditoriale

**Périmètre :** 20 articles.

**Preuve :** Le schéma Article.author.name indique « admin » ; le rendu ne présente pas de signature éditoriale explicite.

**Action :** Afficher une signature réelle ou une équipe clairement identifiée, une courte présentation et les dates pertinentes. Aligner le schéma avec l’auteur affiché.

**Validation :** Auteur identifiable et cohérent entre contenu et JSON-LD.

### SEO-08 / P2 : Contenus commerciaux trop génériques

**Périmètre :** 4 ateliers et produits cadeaux.

**Preuve :** Les ateliers partagent « Un accompagnement à chaque étape » et « Avant de venir ». Plusieurs modalités restent « confirmées par l’atelier ». Stage « week-end » proposé vendredi et samedi.

**Action :** Préciser le programme et les acquis propres à chaque offre, matériel et cuissons inclus ou non, récupération des pièces, rythme exact. Clarifier vendredi/samedi.

**Validation :** Le lecteur différencie chaque formule et connaît les conditions avant de réserver.

### SEO-09 / P2 : Ancrage local et informations vérifiables

**Périmètre :** Accueil, lieu, contact.

**Preuve :** Adresse exacte « à confirmer » et carte centrée sur le quartier. Notes « 4,8/5 » et « 286 avis Google » non justifiées par une fiche source dans l’audit. Aucun schéma Organization ou LocalBusiness détecté.

**Action :** Pour une mise en service réelle, valider adresse, horaires et preuves d’avis ; harmoniser les coordonnées. Compléter l’identité Yoast et, si les informations réelles sont disponibles, le balisage local. Ne pas inventer une adresse ou des évaluations.

**Validation :** Informations locales concordantes et sources vérifiables.

### SEO-10 / P2 : Enrichissement du balisage commercial

**Périmètre :** 3 fiches cartes cadeaux.

**Preuve :** JSON-LD WebPage et BreadcrumbList présents ; aucun type Product détecté dans le DOM de ces fiches.

**Action :** Examiner l’intégration WooCommerce/Yoast et ajouter un Product/Offer cohérent avec les données affichées, sans doublon. Valider les résultats enrichis.

**Validation :** Balisage valide et prix/devise/URL conformes à la fiche ; aucun résultat enrichi garanti.

### SEO-11 / P3 : Images et tutoriels

**Périmètre :** 20 articles et liste du journal.

**Preuve :** 40 attributs alt vides sur 60 images du contenu audité ; certaines images sont décoratives ou redondantes. Les tutoriels reposent surtout sur du texte et une photo générique.

**Action :** Examiner chaque usage : garder alt vide pour les images décoratives, décrire les images informatives. Ajouter des photos originales des étapes et exemples dans les tutoriels prioritaires.

**Validation :** Alternatives pertinentes sans remplissage de mots-clés ; tutoriels illustrés.

### SEO-12 / P3 : Liens vers les offres précises

**Périmètre :** 20 articles.

**Preuve :** Tous les articles ont un lien vers /ateliers/, mais le CTA final est générique.

**Action :** Relier certains articles à l’offre la plus pertinente : tour, modelage, stage, cycle ou cadeau. Garder le guide comme pivot.

**Validation :** Liens contextuels utiles, sans surcharger tous les articles.

## Plan d’action

1. Immédiat : supprimer la description en double, synchroniser les métadonnées de l’accueil, rédiger les titres commerciaux et les descriptions produits.
2. Après correction : vérifier le sitemap actuel et la présence du guide et des cartes cadeaux, lancer le test d’URL active dans Search Console, puis demander leur indexation si tout est accessible.
3. Cette semaine : appliquer les descriptions éditoriales, clarifier les programmes et l’auteur des articles, enrichir les liens vers les offres précises.
4. Sous un mois : suivre impressions, clics, requêtes et pages indexées ; enrichir les tutoriels d’exemples originaux ; vérifier les résultats enrichis et les informations locales réelles.

## Limites et méthode

Relevé des métadonnées et du contenu du DOM rendu, navigation sur toutes les destinations internes sans paramètres trouvées dans les pages relevées. Session navigateur connectée à WordPress : barre d’administration exclue du relevé. La présence des balises ne garantit pas leur rendu identique pour tous les robots ; l’inspection Google complète ce contrôle pour trois URL seulement. Statuts HTTP et en-têtes X-Robots-Tag non mesurés exhaustivement. Liens externes non tous visités. Les 41 URL du sitemap historique ne sont pas intégralement réconciliées avec les 39 URL du périmètre.

Aucune mesure de volumes de mots-clés, positions concurrentes ou backlinks ; aucune donnée SE Ranking ou estimation inventée. Les 34 propositions de métadonnées sont fondées sur le contenu et l’intention de chaque page, à valider avant application. Pas de score SEO global artificiel. Les comptes de mots sont des repères approximatifs du texte visible, pas des seuils de classement. Les 40 alt vides ne sont pas automatiquement 40 erreurs : les images décoratives doivent garder une alternative vide.

## Sources de référence

* Google : [titres](https://developers.google.com/search/docs/appearance/title-link), [descriptions](https://developers.google.com/search/docs/appearance/snippet), [données Article](https://developers.google.com/search/docs/appearance/structured-data/article).
* Google : [robots.txt](https://developers.google.com/search/docs/crawling-indexing/robots/intro), [contenus utiles](https://developers.google.com/search/docs/fundamentals/creating-helpful-content), [balisage local](https://developers.google.com/search/docs/appearance/structured-data/local-business).
* Preuves : pages-auditees.json, inventaire-39-pages.csv, captures et relevés Search Console dans le même dossier.
