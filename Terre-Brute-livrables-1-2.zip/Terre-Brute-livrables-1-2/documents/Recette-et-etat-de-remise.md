# Recette et état de remise

Ce document distingue les contrôles observés des vérifications restant à terminer. Il ne constitue pas un audit de la mission 3.

## Landing et JavaScript

La landing cartes cadeaux comprend un simulateur natif. Contrôle observé : formule Stage, quatre personnes, total 720 €. Une quantité zéro affiche « Vérifiez la quantité ». La FAQ details/summary s’ouvre au clavier et aria-expanded passe à true. Le parcours d’ajout d’une carte cadeau au panier WordPress a été testé.

## Responsive et maquettes

Versions de référence : desktop 1280 px et mobile 390 px, obtenues à partir du document rendu. Les vues de contrôle sont fournies pour 320, 390, 768 et 1440 px. Deux maquettes vectorielles ont été importées dans le fichier Figma demandé ; les textes sont des calques éditables. La fidélité de l’import et la composition finale restent à relire avant soutenance.

## Administration WordPress

Le tableau de bord s’ouvre correctement. Le type Ateliers, les produits, le Journal, les messages et les abonnés disposent de leurs écrans. La page cadeaux utilise des blocs Gutenberg et des shortcodes dynamiques. Le compte éditeur est documenté dans le guide ; son mot de passe est exclu du dossier public.

# Transactions, e-mails et limites



## Réservation de test déjà observée

La commande de test n°69 correspond à une réservation au tour de 55 € avec Stripe TEST. La diminution du stock de huit à sept places avait été contrôlée. Les dates et horaires sont portés dans le panier et la commande. Ne pas réinitialiser les stocks déjà vendus.

## E-mails

L’inscription newsletter et le message de confirmation ont été testés avec l’utilisateur. Le transport Gmail a renvoyé des statuts envoyés dans FluentSMTP. Envoyé signifie accepté par le transport, pas reçu ou lu dans toutes les boîtes. La connexion Google en mode test peut demander une reconnexion.

## Contrôles encore ouverts

Terminer un achat TEST de carte cadeau et vérifier sa date limite d’un an dans la commande et l’e-mail. Refaire une recette complète du filtrage des ateliers et des formulaires avec le compte éditeur. Relire les maquettes Figma à un zoom lisible. Aucun score Lighthouse, WAVE ou EcoIndex n’est revendiqué ici.

## Chatbot ElevenLabs

Le besoin retenu est un assistant français, texte et voix, pour les ateliers, tarifs, cartes cadeaux et réservations. Sa base documentaire et sa configuration sont préparées dans le dossier chatbot. Le compte et l’agent restent à créer ; aucun chatbot opérationnel n’est annoncé dans cette remise.
