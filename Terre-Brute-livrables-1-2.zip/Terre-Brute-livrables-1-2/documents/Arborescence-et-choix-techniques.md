# Arborescence et choix techniques

Dossier de conception et d’exploitation du site pédagogique. Version de remise du 29 octobre 2026.

## Deux versions, un même parcours

La landing statique HTML / CSS / JavaScript présente les cartes cadeaux. Elle est publiée sur GitHub Pages. Le site WordPress constitue le système transactionnel : catalogue, créneaux, panier, paiement Stripe de test, commandes et e-mails. Les boutons de la version statique rejoignent WordPress.

## Liens de référence

Site : https://terre-brute-atelier.rf.gd/
Landing : https://terre-brute-atelier.rf.gd/cartes-cadeaux/
Dépôt : https://github.com/stekinn/terre-brute-landing
Version statique : https://stekinn.github.io/terre-brute-landing/cartes-cadeaux.html
Figma demandé : https://www.figma.com/design/yhNE8liZh7H4gc0UU7i19d/Sans-titre

## Direction artistique

Terracotta #A0472A, beige #EDE6DC, crème #FAF6EF, texte #1F1D1B. Texture terre en arrière-plan, titres Fraunces et texte Inter. Cartes d’offres beiges, boutons terracotta. Le mobile privilégie une colonne, des boutons lisibles et des champs de 16 px.

# Une navigation centrée sur les envies



## Pages éditoriales

Accueil /
Ateliers /ateliers/ : liste filtrable
Cartes cadeaux /cartes-cadeaux/ : landing dédiée
Entreprises et groupes /entreprises-groupes/ : demande de devis
Le lieu /le-lieu/
Journal /journal/ : guide principal et articles
Contact /contact/

## Fiches et transactions

Ateliers : /atelier/initiation-au-tour/, /atelier/initiation-au-modelage/, /atelier/stage-week-end/, /atelier/cycle-trimestriel/
Produits : une carte cadeau par formule ; un produit par créneau daté.
Panier /panier/ > Commande /commande/ > Confirmation de commande.
Mon compte /mon-compte/ : compte et commandes.

## Pages d’information

Mentions légales /mentions-legales/
Conditions générales /cgv/
Confidentialité /confidentialite/
Le contexte pédagogique et le mode test restent documentés dans les pages légales. Aucune adresse de rue non fournie n’est inventée : la carte situe les Chartrons.

# Pourquoi cette architecture ?



## HTML, CSS et JavaScript natifs

La landing est livrée en fichiers séparés, sans framework ni compilation. Le HTML porte les sections et les formulaires ; le CSS gère la présentation et les points de rupture ; gift.js calcule les montants, valide les quantités et synchronise l’état accessible de la FAQ. VS Code sert simplement à ouvrir et modifier ces fichiers.

## WordPress et Gutenberg

Les textes des pages utilisent des blocs natifs : groupes, colonnes, titres, paragraphes, images, boutons et détails. Les offres dynamiques et les formulaires sont insérés par shortcode. Les tarifs et les stocks se modifient dans Produits ; ils ne sont pas ressaisis dans la landing WordPress.

## Extension dédiée plutôt qu’un constructeur

L’extension Terre Brute / Site et ateliers rassemble le type de contenu Ateliers, les modèles, formulaires, réservations, e-mails et styles partagés. Ce choix évite de dupliquer les mises en page et préserve les données lors d’un changement de thème. Le fichier PHP génère le contenu ; le visiteur ne voit que HTML, CSS et JavaScript.

## Limite à connaître

La version statique est un instantané de la landing. Après changement de tarif, de texte ou de photo dans WordPress, son export et son commit GitHub doivent être actualisés. Les modifications de contenu ne remontent pas automatiquement dans Figma.

# Réserver, offrir, recevoir un e-mail



## Ateliers et capacités

tb_atelier est un type de contenu distinct avec durée, prix, capacité, espace et produits associés. tb_type et tb_niveau permettent le filtrage. Chaque produit-créneau WooCommerce possède son propre stock : une unité équivaut à une place. Les commandes en réapprovisionnement sont interdites.

## Horaires et formules

Ouverture du mardi au samedi, 10 h à 19 h. Tour : mercredi 14 h à 16 h 30. Modelage : jeudi 10 h à 12 h 30. Stage : vendredi et samedi, 10 h à 17 h avec pause. Cycle : huit mardis, 10 h à 12 h. Les créneaux passés ne sont plus réservables. Les horaires constituent le planning de démonstration retenu pour ce site.

## Cartes cadeaux

Trois formules : initiation 55 €, stage 180 €, cycle 390 €, par personne. Valables un an à compter de l’achat. Aucune date imposée à l’achat. La référence de commande sert à contacter l’atelier pour choisir une séance. Il ne s’agit pas d’un bon monétaire échangeable automatiquement par code promo.

## Paiement et transport des mails

WooCommerce et l’extension Stripe officielle sont configurés en mode TEST. Les confirmations sont déclenchées par les événements de commande. FluentSMTP transporte les e-mails via l’API Gmail du compte Terre Brute. La newsletter emploie un double opt-in et un lien de désinscription. Les demandes de contact et de devis sont conservées dans WordPress et notifiées à l’équipe.

# Données, rôles et remise



## Rôles et confidentialité

Le compte éditeur sert à gérer les contenus et les produits autorisés. Les clés Stripe, le secret OAuth et la configuration du transport e-mail restent dans l’administration ; ils ne figurent pas dans le dépôt ni dans le dossier public. Les mots de passe sont transmis séparément. Un administrateur conserve l’installation des extensions et les réglages sensibles.

## Sauvegarde de remise

Le dossier comprend la landing et ses ressources locales, les sources de l’extension dédiée, le paquet installable, ce document, le guide utilisateur et la recette. Ce paquet ne constitue pas une sauvegarde complète de la base WordPress. Pour une migration de serveur, il faudra exporter les contenus, la médiathèque et la base, puis reconfigurer les intégrations.

## Périmètre et limites

Les transactions sont simulées. La mission 3 (audit Lighthouse / WAVE / EcoIndex, maintenance et plan de marquage) reste un livrable distinct. La connexion Google en mode test peut demander une reconnexion. Une ouverture commerciale nécessiterait des informations légales réelles, des conditions finalisées et la vérification de la délivrabilité.
