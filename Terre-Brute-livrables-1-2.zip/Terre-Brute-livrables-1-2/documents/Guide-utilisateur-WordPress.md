# Gérer Terre Brute au quotidien

Un guide pour les personnes qui mettent à jour les contenus et les offres, sans écrire de code.

## Se connecter

Ouvrir https://terre-brute-atelier.rf.gd/wp-admin/ puis utiliser le compte éditeur fourni séparément (jeanne.demo). Ne pas partager le compte administrateur. Ne jamais copier un mot de passe ou une clé d’API dans un article, une page ou GitHub.

## Où modifier quoi ?

Pages : textes, images et sections éditoriales.
Ateliers : description, durée, niveau et type d’activité.
Produits : tarif, places disponibles et date d’une séance.
Articles : guides, ressources et tutoriels du Journal.
Commandes, Newsletter, Messages et devis : consultation réservée aux rôles habilités.

## Avant d’enregistrer

Relire le texte, vérifier les liens, prévisualiser la page et contrôler la vue mobile. Mettre à jour une seule offre à la fois. Après une modification importante, noter la date et ce qui a changé.

# Modifier une page et ses images



## Une page existante

1. Ouvrir Pages > Toutes les pages.
2. Choisir la page puis Modifier.
3. Utiliser la Vue en liste pour trouver le groupe ou le titre.
4. Cliquer sur le texte pour le corriger.
5. Prévisualiser puis Enregistrer.

## Changer une image

Sélectionner le bloc Image, puis Remplacer > Médiathèque ou Téléverser. Choisir une photo suffisamment grande, idéalement autour de 1600 px, compressée pour le web. Renseigner un texte alternatif décrivant l’image utilement. Ne pas étirer une petite vignette pour remplir un grand bloc.

## Landing cartes cadeaux

La page « Offrir une parenthèse. » se modifie dans Pages. Les groupes, textes, images et FAQ sont des blocs Gutenberg. Les shortcodes des offres et du calculateur ne doivent pas être effacés. Les prix sont lus depuis les produits. Les couleurs partagées se gèrent dans les styles de l’extension par un administrateur.

## Si le canevas apparaît vide

Dans le navigateur intégré, l’iframe de l’éditeur peut ne pas s’afficher. Essayer dans Chrome ou Firefox habituel et utiliser la Vue en liste. Ne pas remplacer toute la page par un bloc HTML : les blocs éditables seraient perdus.

# Créer ou modifier un atelier



## Ajouter une fiche

1. Ateliers > Ajouter un atelier.
2. Saisir titre, description et extrait.
3. Ajouter une image mise en avant.
4. Sélectionner Type et Niveau.
5. Renseigner Durée, Prix, Capacité et Espace dans les informations de l’atelier.
6. Publier puis vérifier la présence dans la liste filtrable.

## Tour ou modelage ?

Tour : machine tournante, initiation aux gestes de centrage et de façonnage. Modelage : construction manuelle, sans tour. Les deux initiations durent 2 h 30 et sont proposées à 55 €. Le stage offre deux journées ; le cycle comprend huit séances de 2 h.

## Les prix ne se synchronisent pas partout

Le champ Prix de la fiche Ateliers est une information éditoriale. Le montant facturé est celui du produit WooCommerce. Modifier les deux si le tarif change, puis contrôler la landing et la fiche publique. La version statique sur GitHub doit également être réexportée.

# Ajouter une date réservable



## Préparer le produit

Dans Produits, dupliquer un produit-créneau du même type. Mettre le nom de l’atelier et la date dans le titre. Cocher Virtuel, fixer le tarif et conserver le produit simple. Dans Inventaire, activer la gestion du stock, saisir le nombre de places et interdire les commandes en réapprovisionnement.

## Associer la date

Dans Données produit > Général > Réservation Terre Brute, choisir le type et la date de début. Le jour doit correspondre : mercredi pour le tour, jeudi pour le modelage, vendredi pour le stage, mardi pour le cycle. L’association à la fiche Atelier est enregistrée automatiquement. Ne pas utiliser une date passée.

## Vérifier avant d’annoncer

Ouvrir la fiche publique de l’atelier. La nouvelle date doit apparaître dans le sélecteur avec son horaire et ses places. La choisir, ajouter une place au panier et vérifier date, horaire et tarif. Retirer l’article de test après contrôle. Une commande payée réduit le stock ; ne pas remettre toutes les places à la capacité initiale si des places sont déjà vendues.

## Cas du cycle

Le cycle réserve huit séances liées. Éviter de créer deux cohortes simultanées dans le même espace et au même horaire. Vérifier le planning de l’équipe avant d’ajouter un nouveau départ.

# Cartes cadeaux et commandes



## Modifier une formule cadeau

Produits > ouvrir la carte souhaitée > Général > Tarif régulier > Mettre à jour. Les trois formules sont Initiation, Stage et Cycle. Le bénéficiaire choisit une date plus tard avec l’atelier. La durée de validité est d’un an à compter de l’achat et sa date limite est enregistrée dans la commande après paiement.

## Traiter une demande de bénéficiaire

Demander la référence de commande, vérifier son statut payé, sa formule, sa quantité et sa date de validité. Chercher un créneau avec assez de places puis enregistrer l’attribution et une note interne de suivi. La réservation par carte cadeau est gérée avec l’équipe : il n’y a pas de code de réduction généré automatiquement.

## Démontrer le paiement

Utiliser seulement Stripe TEST et la carte de démonstration indiquée par Stripe. Ne jamais saisir de carte réelle. Après le test, vérifier le numéro et le statut de commande, le stock du créneau et le journal des e-mails. Une simple page « merci » ne suffit pas à prouver le paiement.

## Accès et autorisations

Les écrans de commandes et les réglages de paiement sont réservés aux personnes habilitées. Un éditeur qui ne les voit pas doit passer par l’administrateur ; ne pas changer son rôle lui-même.

# Journal, formulaires et e-mails



## Publier un article

Articles > Ajouter. Saisir un titre, une introduction, des intertitres et le contenu. Choisir une catégorie cohérente, une image mise en avant et un extrait. Ajouter des liens vers le guide principal et vers un atelier pertinent. Prévisualiser puis publier. Vérifier la présence dans le Journal.

## Contact et devis

Les formulaires du site enregistrent les demandes dans Messages et devis. Le devis comporte entreprise, participants, date souhaitée, budget et type d’événement. L’équipe reçoit une notification et le visiteur un accusé de réception. Cet accusé ne confirme aucune réservation.

## Newsletter

Une case de consentement est obligatoire. Après inscription, la personne reçoit un mail de confirmation. Elle doit confirmer sur le site avant activation et réception du mail de bienvenue. Les inscriptions et leur état se consultent dans Newsletter par un administrateur. Le lien de désinscription permet de sortir de la liste active.

## En cas d’e-mail absent

Vérifier les spams, puis Réglages > FluentSMTP > Journaux des e-mails. Un statut envoyé indique une acceptation par Gmail, pas une preuve de lecture. Si la connexion Google a expiré, demander à l’administrateur de la reconnecter. Ne pas réactiver Resend en parallèle sans vérifier le conflit de transport.
