document.addEventListener('DOMContentLoaded',function(){
 const track=document.querySelector('.tb-review-track');if(!track)return;
 track.setAttribute('tabindex','0');track.setAttribute('role','region');track.setAttribute('aria-label','Exemples d’avis, défilement horizontal');
 const controls=document.createElement('div');controls.className='tb-review-controls';
 const prev=document.createElement('button'),next=document.createElement('button'),count=document.createElement('span');
 prev.type=next.type='button';prev.textContent='←';next.textContent='→';prev.setAttribute('aria-label','Avis précédents');next.setAttribute('aria-label','Avis suivants');
 controls.append(prev,count,next);track.after(controls);
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 function step(){return track.children[0].getBoundingClientRect().width+24}
 function update(){const first=Math.round(track.scrollLeft/step())+1;const last=Math.min(track.children.length,Math.round((track.scrollLeft+track.clientWidth+24)/step()));count.textContent=(first===last?first:first+'–'+last)+' / '+track.children.length}
 function move(direction){const max=track.scrollWidth-track.clientWidth;const target=direction>0&&track.scrollLeft>=max-4?0:direction<0&&track.scrollLeft<=4?max:Math.max(0,Math.min(max,track.scrollLeft+direction*step()));track.scrollTo({left:target,behavior:reduced.matches?'instant':'smooth'})}
 prev.addEventListener('click',()=>move(-1));next.addEventListener('click',()=>move(1));
 track.addEventListener('keydown',e=>{if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();move(e.key==='ArrowRight'?1:-1)}});
 track.addEventListener('scroll',update,{passive:true});window.addEventListener('resize',update);update();
});
