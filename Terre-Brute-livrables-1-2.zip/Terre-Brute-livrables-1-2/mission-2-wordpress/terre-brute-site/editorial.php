<?php
if(!defined('ABSPATH'))exit;
function tbs_natural_punctuation($html){
 $parts=wp_html_split($html);
 foreach($parts as &$part){if($part===''||$part[0]==='<')continue;
  // Horaires et intervalles : « 10 h à 19 h ». Les traits internes restent intacts.
  $part=preg_replace('/(\d(?:[\d\s\x{00a0}h]*))\s*[–—]\s*(?=\d)/u','$1 à ',$part);
  $part=preg_replace('/\s*[—–]\s*/u',' : ',$part);
  $part=preg_replace('/(?<=\S)\s+-\s+(?=\S)/u',' : ',$part);
 }
 unset($part);return implode('',$parts);
}
add_filter('the_content','tbs_natural_punctuation',999);
add_filter('the_title','tbs_natural_punctuation',99);
add_filter('get_the_excerpt','tbs_natural_punctuation',99);
// Enregistre aussi la correction dans les blocs éditables, sans modifier HTML, URL ou identifiants.
add_action('admin_init',function(){if(!current_user_can('manage_options')||get_option('tbs_editorial_punctuation')==='1')return;
 $posts=get_posts(array('post_type'=>array('page','post','product','tb_atelier'),'post_status'=>array('publish','draft','future'),'numberposts'=>-1));
 foreach($posts as $post){$data=array('ID'=>$post->ID);foreach(array('post_title','post_content','post_excerpt') as $field){$clean=tbs_natural_punctuation($post->$field);if($clean!==$post->$field)$data[$field]=$clean;}if(count($data)>1)wp_update_post(wp_slash($data));$label=get_post_meta($post->ID,'_tbs_booking_label',true);if($label)update_post_meta($post->ID,'_tbs_booking_label',tbs_natural_punctuation($label));}
 update_option('tbs_editorial_punctuation','1');
});
