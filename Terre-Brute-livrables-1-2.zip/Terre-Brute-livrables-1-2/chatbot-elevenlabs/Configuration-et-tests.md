# Terra / Configuration livrée le 29 octobre 2026

Agent public : agent_7801m63ezfz6fh7rt2sz12gncp4e
Langue principale : français. Voix : Claire / Conversationnel.
Base de connaissances : Terre Brute / offres et informations pratiques / 29 octobre 2026, attachée à l’agent.

Le widget permet des échanges textuels et vocaux, commence réduit et se place en bas à gauche. Palette : crème #FAF6EF, terracotta #A0472A, texte #1F1D1B. Les réponses peuvent contenir des liens vers terre-brute-atelier.rf.gd et stekinn.github.io. Cette liste concerne les liens cliquables ; elle ne doit pas être confondue avec une restriction d’origine de l’agent.

Intégration WordPress : module assistant.php de l’extension Terre Brute Site et ateliers 1.0.29. Réglages > Assistant Terra permet de modifier l’identifiant public ou de désactiver le widget en vidant le champ. Aucune clé d’API n’est exposée. Le widget n’est pas chargé sur le paiement. La page de confidentialité comporte une section sur ElevenLabs.

## Tests réellement observés sur WordPress

- Deux initiations : Terra indique 110 €.
- Ouverture lundi : Terra indique la fermeture, et mardi à samedi 10 h à 19 h.
- Validité carte cadeau : Terra indique un an sans date imposée à l’achat.
- Demande de réservation : Terra explique ne pas pouvoir réserver ni confirmer et renvoie vers la fiche Atelier par un lien cliquable.
- Le widget reprend les couleurs de l’atelier et laisse le panier à droite.

## Reste à vérifier

Le test vocal avec microphone a été reporté à la demande de l’utilisateur. Le bouton vocal et la voix sont configurés, mais la qualité de l’échange oral n’est pas certifiée par la recette. Vérifier le quota du compte avant la soutenance et relire la configuration de conservation des conversations. Ne pas envoyer de données personnelles ou bancaires dans l’assistant.

L’assistant ne lit pas les stocks en direct, ne modifie aucune commande et n’envoie aucun e-mail. Ses informations doivent être mises à jour dans ElevenLabs lorsque les offres changent, puis publiées.

Documentation officielle :
https://elevenlabs.io/docs/eleven-agents/customization/widget
https://elevenlabs.io/docs/eleven-agents/guides/no-code/word-press
