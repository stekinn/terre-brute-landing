# Terre Brute Atelier / Informations publiques

## Le lieu
Atelier de céramique de 160 m², quartier des Chartrons, Bordeaux. Un espace supplémentaire de 90 m² est annoncé pour janvier 2027, pour les groupes et les stages. L’adresse exacte de rue n’est pas fournie : ne pas en inventer une. La carte actuelle situe le quartier.
Ouverture : du mardi au samedi de 10 h à 19 h. Fermeture dimanche et lundi.

## Offres
- Initiation au tour : 55 € par personne, 2 h 30. Découverte d’un tour de potier, centrage et premiers gestes. Créneaux de référence : mercredi 14 h à 16 h 30 ; vérifier les dates proposées sur le site.
- Initiation au modelage : 55 € par personne, 2 h 30. Façonnage manuel sans tour. Créneaux de référence : jeudi 10 h à 12 h 30 ; vérifier les dates du site.
- Stage : 180 € par personne, deux jours, vendredi et samedi de 10 h à 17 h. Pause de 12 h 30 à 14 h.
- Cycle : 390 € par personne, huit séances de 2 h, le mardi de 10 h à 12 h. Consulter les départs proposés.
Aucune expérience nécessaire pour une initiation. Pour les restrictions d’âge, besoins spécifiques, matériel à apporter ou délais de cuisson non précisés, demander à l’équipe ; ne pas improviser.

## Réservation
La personne choisit un atelier puis un produit-créneau daté. La date et l’horaire sont obligatoires pour une réservation d’atelier. Les capacités sont gérées dans WooCommerce ; l’assistant n’a pas accès aux stocks en direct. Le site utilise Stripe en mode TEST. Ne pas demander de vraie carte pour une démonstration.

## Cartes cadeaux
Trois formules : initiation 55 €, stage 180 €, cycle 390 €, par personne. Validité : un an à compter de l’achat. Pas de date imposée à l’achat. Le bénéficiaire contacte l’équipe avec la référence de commande pour choisir un créneau disponible. Pas de code promotionnel ou de réservation automatique par l’assistant.

## Groupes et contact
Une page Entreprises et groupes permet une demande de devis. L’accusé de réception d’un formulaire n’est pas une confirmation de réservation. Les conditions d’annulation/report doivent être consultées dans les CGV ou confirmées par l’équipe.

## Newsletter et Journal
Newsletter avec consentement et confirmation par e-mail, puis message de bienvenue. Désinscription via le lien du mail. Le Journal propose des guides, ressources et tutoriels autour de la céramique.

## Liens utiles
Accueil : https://terre-brute-atelier.rf.gd/
Ateliers : https://terre-brute-atelier.rf.gd/ateliers/
Tour : https://terre-brute-atelier.rf.gd/atelier/initiation-au-tour/
Modelage : https://terre-brute-atelier.rf.gd/atelier/initiation-au-modelage/
Stage : https://terre-brute-atelier.rf.gd/atelier/stage-week-end/
Cycle : https://terre-brute-atelier.rf.gd/atelier/cycle-trimestriel/
Cartes cadeaux : https://terre-brute-atelier.rf.gd/cartes-cadeaux/
Entreprises : https://terre-brute-atelier.rf.gd/entreprises-groupes/
Contact : https://terre-brute-atelier.rf.gd/contact/
Journal : https://terre-brute-atelier.rf.gd/journal/
CGV : https://terre-brute-atelier.rf.gd/cgv/
